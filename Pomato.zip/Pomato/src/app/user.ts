export class User{
    id: number;
    name: string;
    email: string;
    phoneNumber: string;
    username: string;
    password: string;
}