export class Cart{
    id: number;
    foodItem: string;
    foodQuantity: string;
    cost: number;
}