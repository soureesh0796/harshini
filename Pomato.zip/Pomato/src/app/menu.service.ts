import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

import { Menu } from './menu';

@Injectable()
export class MenuService {
    constructor(private http: HttpClient) { }

    public listMenu(){
        return this.http.get<Menu[]>("http://localhost:8089/listMenu");
    }

    addToCart(menu): Observable<any> {
        return this.http.post('http://localhost:8089/addToCart/',menu,{responseType:'text'});
    }
}