import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { User } from '../user';
import { Router } from '@angular/router';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  isValidFormSubmitted = false;
  user = new User();

  constructor(private router: Router) { }

  ngOnInit() {
  }

  onFormSubmit(form: NgForm) {
    if (form.invalid) {
      return;
    }

    this.isValidFormSubmitted = true;
    this.router.navigate(['/menu']);
    this.user = form.value;
    this.user = new User();
    form.resetForm;
  }
}
