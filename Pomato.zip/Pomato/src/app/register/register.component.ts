import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import { User } from '../user';
import { UserService } from '../user.service';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  isValidFormSubmitted = false;
  user = new User();
  message: string;
  exists: boolean=false;


  constructor(private router: Router, private userService: UserService) { }

  ngOnInit() {
  }

  createUser() {
    this.userService.createUser(this.user)
      .subscribe(data => {
        if (data) {
          this.router.navigate(['/login']);
          console.log(data);
        }
      }, error => {
        if (error = "User Already Exists") {
          this.exists=true;
          this.message="User already exists! Please try again with a different email-id or username.";
          this.router.navigate(['/register']);
          setTimeout(function(){
            this.exists=false;
          }.bind(this),4000);
        }
      }
      );

  }
  onFormSubmit(form: NgForm) {
    if (form.invalid) {
      return;
    }
    this.createUser();
    this.user = form.value;
    //this.user = new User();
    //form.resetForm;
  }
}
