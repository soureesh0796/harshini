package com.food.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.food.model.Item;

public interface ItemRepository extends JpaRepository<Item, Integer>{

}
