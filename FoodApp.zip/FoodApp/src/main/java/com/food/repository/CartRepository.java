package com.food.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.food.model.Cart;

public interface CartRepository extends JpaRepository<Cart, Integer> {
	
	@Query("select sum(cost) from Cart")
	public Integer getTotalCost();

}
