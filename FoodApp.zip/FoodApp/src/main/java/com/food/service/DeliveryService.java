package com.food.service;

import java.util.List;

import com.food.model.Cart;
import com.food.model.Item;

public interface DeliveryService {

	List<Item> listMenu();

	void addToCart(Item item);

	List<Cart> listCart();

	int getTotalCost();

	void proceedToPay();


	
	

}
