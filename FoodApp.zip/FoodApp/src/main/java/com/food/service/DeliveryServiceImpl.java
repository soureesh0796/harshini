package com.food.service;

import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.food.model.Cart;
import com.food.model.Item;
import com.food.repository.CartRepository;
import com.food.repository.ItemRepository;

@Service("deliveryService")
public class DeliveryServiceImpl implements DeliveryService {

	@Autowired
	ItemRepository itemRep;

	@Autowired
	CartRepository cartRep;

	@Override
	public List<Item> listMenu() {
		return itemRep.findAll();
	}

	@Override
	@Transactional
	public void addToCart(Item item) {
		Item orderedItem = itemRep.findOne(item.getId());
		Cart cart = new Cart();
		cart.setFoodItem(orderedItem.getItemName());
		cart.setFoodQuantity(item.getQuantity());
		cart.setCost(orderedItem.getPrice() * item.getQuantity());
		cartRep.save(cart);
		
		orderedItem.setQuantity(orderedItem.getQuantity()-item.getQuantity());
		itemRep.save(orderedItem);
	}

	@Override
	@Transactional
	public List<Cart> listCart() {
		return cartRep.findAll();
	}

	@Override
	@Transactional
	public int getTotalCost() {

		if(cartRep.getTotalCost()==null) {
			return 0;
		}
		return cartRep.getTotalCost();
	}

	@Override
	public void proceedToPay() {
		List<Cart> cartList=cartRep.findAll();
		for(Cart cart: cartList) {
			cartRep.delete(cart);
		}
	}

}
