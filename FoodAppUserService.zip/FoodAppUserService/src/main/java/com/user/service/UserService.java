package com.user.service;

import com.user.exception.UserAlreadyExistsException;
import com.user.model.User;

public interface UserService {

	boolean createUser(User user) throws UserAlreadyExistsException;

}
